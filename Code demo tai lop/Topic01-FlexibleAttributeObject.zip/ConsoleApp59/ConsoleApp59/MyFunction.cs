﻿namespace ConsoleApp59
{
    public class MyFunction
    {
    }
}