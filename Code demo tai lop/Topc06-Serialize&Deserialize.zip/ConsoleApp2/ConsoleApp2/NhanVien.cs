﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    public abstract class NhanVien
    {
        public int MaSo;
        public string HoTen;

        internal static NhanVien Recruit(int t)
        {
            if (t == 0)
                return new NhanVienVanPhong();
            else
                return new NhanVienSanXuat();
        }

        public virtual double TinhLuong()
        {
            return 0.0;
        }

        internal void SaveToFile(StreamWriter sw)
        {
            SaveTypeToStream(sw);
            sw.WriteLine(MaSo.ToString());
            sw.WriteLine(HoTen);
            SaveExtraAttributesToFile(sw);
            
        }

        protected virtual void SaveTypeToStream(StreamWriter sw)
        {
            
        }

        protected virtual void SaveExtraAttributesToFile(StreamWriter sw)
        {

        }

        internal static NhanVien CreateObjectFromStream(StreamReader sr)
        {
            int t = int.Parse(sr.ReadLine());
            return NhanVien.Recruit(t);
        }

        internal void LoadFromFile(StreamReader sr)
        {
            MaSo = int.Parse(sr.ReadLine());
            HoTen = sr.ReadLine();
            ReadExtraAttributesToFile(sr);
        }

        protected virtual void ReadExtraAttributesToFile(StreamReader sr)
        {
            
        }
    }
}