﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    public class NhanVienVanPhong : NhanVien
    {
        public double LuongMoiThang;
        public int SoNgayDiLamTrongThang;
        public override double TinhLuong()
        {
            return SoNgayDiLamTrongThang * LuongMoiThang / 22;
        }


        protected override void ReadExtraAttributesToFile(StreamReader sr)
        {
            // Doc thong tin Luong moi thang va so ngay di lam trong thang
        }
        protected override void SaveTypeToStream(StreamWriter sw)
        {
            sw.WriteLine("0");
        }
        protected override void SaveExtraAttributesToFile(StreamWriter sw)
        {
            sw.WriteLine(LuongMoiThang.ToString());
            sw.WriteLine(SoNgayDiLamTrongThang.ToString());
        }
    }
}