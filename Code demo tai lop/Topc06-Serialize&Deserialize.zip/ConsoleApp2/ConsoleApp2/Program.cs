﻿// See https://aka.ms/new-console-template for more information
using ConsoleApp2;

Console.WriteLine("Hello, World!");
int nNhanVien = 0;
nNhanVien = int.Parse(Console.ReadLine());

NhanVien[] nhanViens = new NhanVien[nNhanVien];
for (int i = 0; i< nNhanVien; i++)
{
    int t = int.Parse(Console.ReadLine());
    nhanViens[i] = NhanVien.Recruit(t);
}

SaveDanhSachNhanVien(nhanViens, "list.txt");
NhanVien[] l;
l = LoadDanhSachNhanVien("list.txt");

NhanVien[] LoadDanhSachNhanVien(string strFilename)
{
    StreamReader sr = new StreamReader(strFilename);
    int n = int.Parse(sr.ReadLine());
    for (int i=0; i< n; i++)
    {
       nhanViens[i]= NhanVien.CreateObjectFromStream(sr);
        nhanViens[i].LoadFromFile(sr);
    }
    sr.Close();
}

void SaveDanhSachNhanVien(NhanVien[] nhanViens, string strFilename)
{
    StreamWriter sw = new StreamWriter(strFilename);
    sw.WriteLine(nhanViens.Length);
    for (int i=0; i<nhanViens.Length; i++)
    {
        nhanViens[i].SaveToFile(sw);
    }
    sw.Close();
}