﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    public class NhanVienSanXuat : NhanVien
    {
        public double DonGiaSanPham;
        public int SoLuongSanPham;
        public override double TinhLuong()
        {
            return DonGiaSanPham * SoLuongSanPham;
        }

        protected override void ReadExtraAttributesToFile(StreamReader sr)
        {
            // Doc thong tin Don gia san pham va so luong san pham
        }

        protected override void SaveTypeToStream(StreamWriter sw)
        {
            sw.WriteLine("1");
        }
        protected override void SaveExtraAttributesToFile(StreamWriter sw)
        {
            sw.WriteLine(DonGiaSanPham.ToString()); 
            sw.WriteLine(SoLuongSanPham.ToString());

        }
    }
}