﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp63
{
    class Program
    {
        static void Main(string[] args)
        {
            NewsChannel K19FIT = new NewsChannel("K19FIT");
            NewsChannel K19FIT4Fun = new NewsChannel("K19FIT-4Fun");
            Member sv1 = new Member("Nguyen Dang Tien Thanh");
            Member sv2 = new Member("Le Cong Binh");
            Member sv3 = new Member("Nguyen Nhat Minh Khoi");
            Member sv4 = new Member("Nguyen Le Bao Thi");

            K19FIT.Subscribe(sv1, new List<string> { "code", "music", "scholarship" });
            K19FIT.Subscribe(sv3, new List<string> { "postgraduate", "scholarship", "eat"});

            Article a1 = new Article("content", new List<string> { "scholarship" });

            K19FIT.PostArticle(a1, sv1);

        }
    }
}
