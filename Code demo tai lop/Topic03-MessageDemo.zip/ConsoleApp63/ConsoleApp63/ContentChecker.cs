﻿using System;
using System.Collections.Generic;

namespace ConsoleApp63
{
    internal class ContentChecker
    {
        public virtual bool IsAppropriate(Article article, 
            Member member, 
            List<string> preference)
        {
            return true;
        }
    }
}