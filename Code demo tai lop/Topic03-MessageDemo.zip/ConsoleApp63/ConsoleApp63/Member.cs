﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp63
{
    public class Member
    {
        internal int ID;
        public string HoTen;
        private static int NextAvailableID=1;

        public Member(string hoten)
        {
            this.HoTen = hoten;
            this.ID = Member.NextAvailableID++;
        }

        internal void Notify(NewsChannel newsChannel, Article article)
        {
            Console.WriteLine(this.HoTen + " reads " + article.content);
        }
    }
}