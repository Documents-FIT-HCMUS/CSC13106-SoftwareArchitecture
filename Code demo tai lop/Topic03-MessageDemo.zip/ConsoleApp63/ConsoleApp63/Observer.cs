﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp63
{
    public class Observer
    {
        internal void Notify(Subject subject)
        {
            throw new NotImplementedException();
        }
    }
}