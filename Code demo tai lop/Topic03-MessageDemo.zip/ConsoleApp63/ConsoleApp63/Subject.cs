﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp63
{
    public class Subject
    {
        protected List<Observer> subscribers = new List<Observer>();
        public bool Subscribe(Observer o)
        {
            subscribers.Add(o);
            return true;
        }

        public bool Unsubscribe(Observer o)
        {
            return subscribers.Remove(o);
        }

        public void NotifyAll()
        {
            foreach (Observer o in subscribers)
                o.Notify(this);

        }

    }
}