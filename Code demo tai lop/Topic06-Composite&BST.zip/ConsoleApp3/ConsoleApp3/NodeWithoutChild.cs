﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3
{
    public class NodeWithoutChild : Node
    {
        public override int TotalValue()
        {
            return V;
        }
        public override Node SearchValue(int k)
        {
            if (V == k)
                return this;
            return null;
        }
    }
}