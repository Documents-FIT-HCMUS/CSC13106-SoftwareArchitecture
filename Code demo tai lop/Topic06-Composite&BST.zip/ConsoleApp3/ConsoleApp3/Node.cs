﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3
{
    public abstract class Node
    {
        public int V;
        public virtual int TotalValue()
        {
            return 0;
        }

        public virtual Node SearchValue(int k)
        {
            return null;
        }
    }
}