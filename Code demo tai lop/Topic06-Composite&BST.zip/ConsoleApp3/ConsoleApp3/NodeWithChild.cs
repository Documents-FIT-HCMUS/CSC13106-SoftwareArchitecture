﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3
{
    public class NodeWithChild : Node
    {
        public Node pLeft; 
        public Node pRight;
        public override int TotalValue()
        {
            int t = V;
            if (pLeft != null)
            {
                t += pLeft.TotalValue();
            }
            if (pRight != null)
            {
                t += pRight.TotalValue();   
            }
            return t;
        }
        public override Node SearchValue(int k)
        {
            if (V == k)
                return this;
            else if (V > k)
            {
                if (pLeft != null)
                    return pLeft.SearchValue(k);
                else
                    return null;
            } else // V < k
            {
                if (pRight != null)
                    return pRight.SearchValue(k);
                else
                    return null;
            }
        }
    }
}