﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp3
{
    public class MNode
    {
        NodeState state = new NodeState_WithoutChild();
    }
}