﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp19
{
    public class DefaultCopyOneToOne : MappingEngine
    {
        public override bool Execute(MyObject sourceObject, string[] sourceAttributeNames, MyObject targetObject, string[] targetAttributeNames)
        {
            if (sourceAttributeNames.Length != 1)
                return false;
            if (targetAttributeNames.Length != 1)
                return false;
            if (sourceObject[sourceAttributeNames[0]] == null)
                return false;
            targetObject[targetAttributeNames[0]] = sourceObject[sourceAttributeNames[0]];
            return true;
        }
    }
}