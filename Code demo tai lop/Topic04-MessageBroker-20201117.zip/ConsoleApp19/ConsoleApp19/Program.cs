﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp19
{
    class Program
    {
        static void Main(string[] args)
        {
            /*            MyObject sourceObject = new MyObject();
                        MyObject targetObject = new MyObject();
                        sourceObject["First Name"] = "A";
                        sourceObject["Last Name"] = "Nguyen";
                        sourceObject["Middle Name"] = "Van";
                        sourceObject["GPA"] = 4.0;

                        targetObject["Ho va ten sinh vien"] = sourceObject["Last Name"] + " " + 
                            sourceObject["Middle Name"] + " " + 
                            sourceObject["First Name"];
                        double GPA = (double)sourceObject["GPA"];
                        if (GPA == 4)
                            targetObject["DTB"] = 10.0;*/

            MappingManager mappingManager = new MappingManager();
/*            mappingManager.AddRule(new string[] { "Last Name", "Middle Name", "First Name" },
                                   new string[] { "Ho va ten" },
                                   new ConcatenateAllStrings());
            mappingManager.AddRule(new string[] { "Last Name", "Middle Name"},
                                   new string[] { "Ho va chu lot" },
                                   new ConcatenateAllStrings());
            mappingManager.AddRule(new string[] { "First Name"},
                                   new string[] { "Ten" },
                                   new DefaultCopyOneToOne());
            mappingManager.AddRule(new string[] { "Credit" },
                                   new string[] { "So tin chi" },
                                   new DefaultCopyOneToOne());

            mappingManager.AddRule(new string[] { "Latitude" },
                                   new string[] { "Vĩ độ" },
                                   new DefaultCopyOneToOne());

            mappingManager.AddRule(new string[] { "Longitude" },
                                   new string[] { "Kinh độ" },
                                   "DefaultCopyOneToOne");
                                   */
            mappingManager.LoadRulesFromFile(@"C:\Temp\rules20201117.txt"); // not good!!!

            MyObject a, b;
            a = new MyObject();
            b = new MyObject();
            a["First Name"] = "A";
            a["Middle Name"] = "B";
            a["Last Name"] = "C";
            a["Telephone"] = "0987654321";
            a["Email"] = "abc@xyz.com";

            b["Ho va ten"] = "";
            b["Ho va chu lot"] = "";
            b["Ten"] = "";
            b["DTB"] = 0;
            b["Dien thoai"] = "";

            string[] allAttributeNames = b.GetAllAttributeNames();

            mappingManager.MapObjectToObject(a, b);
            for (int i = 0; i < allAttributeNames.Length; i++)
                Console.WriteLine(allAttributeNames[i] + " = " + b[allAttributeNames[i]].ToString());




        }
    }
}
