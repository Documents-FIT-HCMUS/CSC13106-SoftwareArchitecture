﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp19
{
    public class ConcatenateAllStrings : MappingEngine
    {
        public override bool Execute(MyObject sourceObject, string[] sourceAttributeNames, MyObject targetObject, string[] targetAttributeNames)
        {
            if (targetAttributeNames.Length != 1)
                return false;
            if (sourceAttributeNames.Length == 0)
                return false;

            string temp = "";
            for (int i = 0; i < sourceAttributeNames.Length; i++)
            {
                temp += sourceObject[sourceAttributeNames[i]];
                if (i < sourceAttributeNames.Length - 1)
                    temp += " ";
            }

            targetObject[targetAttributeNames[0]] = temp;
            return true;
        }
    }
}