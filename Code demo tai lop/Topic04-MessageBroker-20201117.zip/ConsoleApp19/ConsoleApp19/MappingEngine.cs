﻿using System;
using System.Collections.Generic;

namespace ConsoleApp19
{
    public class MappingEngine
    {
        public virtual bool Execute(MyObject sourceObject, string[] sourceAttributeNames, MyObject targetObject, string[] targetAttributeNames)
        {
            return true;
        }

        private static Dictionary<string, MappingEngine> engines = new Dictionary<string, MappingEngine>();

        static MappingEngine()
        {
            engines.Add("DefaultCopyOneToOne", new DefaultCopyOneToOne());
            engines.Add("ConcatenateAllStrings", new ConcatenateAllStrings());
        }
        internal static MappingEngine FromName(string strEngineName)
        {
            return engines[strEngineName];
        }
    }
}