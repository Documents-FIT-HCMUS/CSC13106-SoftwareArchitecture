﻿namespace ConsoleApp61
{
    internal class SStudent:SObject
    {
        public SStudent()
        {
        }
    }
}