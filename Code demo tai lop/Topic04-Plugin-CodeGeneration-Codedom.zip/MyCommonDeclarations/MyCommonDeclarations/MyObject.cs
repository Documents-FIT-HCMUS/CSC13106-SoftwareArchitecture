﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCommonDeclarations
{
    public class MyObject
    {
        private AttributeList attributes = new AttributeList();

        public object this[string strAttributeName]
        {
            get
            {
                return attributes[strAttributeName];
            }
            set
            {
                attributes[strAttributeName] = value;
            }
        }

        public bool ContainAttribute(string strName)
        {
            return attributes.ContainAttribute(strName);
        }

        public string[] GetAllAttributeNames()
        {
            return attributes.GetAllAttributeNames();
        }

    }
}
