﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCommonDeclarations
{
    public interface ICommand
    {
        string GetName();
        bool Execute(object[] input, ref object[] output);


    }
}
