﻿using System.Collections.Generic;
using System.Linq;

namespace MyCommonDeclarations
{
    public class AttributeList
    {
        private Dictionary<string, object> attributes = new Dictionary<string, object>();
        public bool bAutoAddNew = true;

        public object this[string strAttributeName]
        {
            get
            {
                if (attributes.ContainsKey(strAttributeName))
                    return attributes[strAttributeName];
                else
                    return null;
            }
            set
            {
                if (attributes.ContainsKey(strAttributeName))
                {
                    attributes[strAttributeName] = value;
                }
                else if (bAutoAddNew)
                {
                    attributes.Add(strAttributeName, value);
                }
            }
        }

        public string[] GetAllAttributeNames()
        {
            return attributes.Keys.ToArray();
        }

        public bool ContainAttribute(string strName)
        {
            return attributes.ContainsKey(strName);
        }

    }
}