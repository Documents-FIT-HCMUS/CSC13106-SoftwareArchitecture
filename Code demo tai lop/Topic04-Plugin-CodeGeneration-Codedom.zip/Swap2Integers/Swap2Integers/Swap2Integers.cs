﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swap2Integers
{
    class Swap2Integers : MyCommonDeclarations.ICommand
    {
        public bool Execute(object[] input, ref object[] output)
        {
            try
            {
                int v0 = int.Parse((string)input[0]);
                int v1 = int.Parse((string)input[1]);
                output = new object[2];
                output[0] = v1;
                output[1] = v0;
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public string GetName()
        {
            return "Swap 2 integers";
        }
    }
}
