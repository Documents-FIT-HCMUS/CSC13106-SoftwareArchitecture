﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp8
{
    public class Add2Integers : MyCommonDeclarations.ICommand
    {
        public bool Execute(object[] input, ref object[] output)
        {
            // input[0] + input[1]
            try
            {
                int v0 = int.Parse((string)input[0]);
                int v1 = int.Parse((string)input[1]);
                int res = v0 + v1;
                output = new object[1];
                output[0] = res;
                return true;
            }
            catch(Exception)
            {
                output = new object[0];
                return false;
            }
        }

        public string GetName()
        {
            return "Add 2 integers";
        }
    }
}