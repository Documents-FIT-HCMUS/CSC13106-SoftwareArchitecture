﻿using Microsoft.CSharp;
using MyCommonDeclarations;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddFunction(new Add2Integers());
            AddFunction(new MaxNDoubleNumbers());
        }

        List<MyCommonDeclarations.ICommand> functions = new List<MyCommonDeclarations.ICommand>();

        private void AddFunction(MyCommonDeclarations.ICommand f)
        {
            functions.Add(f);
            comboBox1.Items.Add(f.GetName());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1) return;

            int selIdx = comboBox1.SelectedIndex;
            object[] input, output = null;
            input = PrepareInputData();
            bool b = functions[selIdx].Execute(input, ref output);
            if (b)
            {
                string res = Output2String(output);
                textBox6.Text = res;
            }
        }

        private object[] PrepareInputData()
        {
            string[] strParams = CollectAllInputs();
            object[] input = new object[strParams.Length];
            for (int i = 0; i < strParams.Length; i++)
                input[i] = strParams[i];
            return input;
        }

        private string[] CollectAllInputs()
        {
            int n = 5;
            TextBox[] textBoxes = new TextBox[]
            {
                textBox1, textBox2, textBox3, textBox4, textBox5
            };
            List<string> temp = new List<string>();
            for (int i=0; i<n; i++)
                if (textBoxes[i].Text == "")
                {
                    return temp.ToArray();
                }
                else
                {
                    temp.Add(textBoxes[i].Text);
                }
            return temp.ToArray();                    
        }

        private string Output2String(object[] output)
        {
            string s = "";
            for (int i=0; i<output.Length; i++)
            {
                s += output[i].ToString() + " ";
            }
            return s;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() != DialogResult.OK)
                return;
            MyCommonDeclarations.ICommand f = LoadFunction(dlg.FileName);
            if (f!=null)
                AddFunction(f);
        }

        private ICommand LoadFunction(string fileName)
        {
            Assembly asm = LoadBinaryFileToMemory(fileName);
            return CreateFunctionInASM(asm);
        }

        private ICommand CreateFunctionInASM(Assembly asm)
        {
            Type[] types = asm.GetTypes();
            MyCommonDeclarations.ICommand temp;
            foreach(Type t in types)
            {
                try
                {
                    temp = (MyCommonDeclarations.ICommand)
                        Activator.CreateInstance(t);
                    return temp;
                }
                catch(Exception)
                {

                }
            }
            return null;
        }

        private Assembly LoadBinaryFileToMemory(string fileName)
        {
            return Assembly.LoadFile(fileName);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string strContentOfGetName = textBox7.Text;
            string strContentOfExecute = textBox8.Text;
            string strFullCode = GenAllCode
                (strContentOfGetName, strContentOfExecute);

            Assembly asm = LoadModuleFromSourceCode(strFullCode);

            MyCommonDeclarations.ICommand f =  CreateFunctionInASM(asm);
            AddFunction(f);
        }

        private Assembly LoadModuleFromSourceCode(string strFullCode)
        {
            CSharpCodeProvider provider = new CSharpCodeProvider();

            // Build the parameters for source compilation.
            CompilerParameters cp = new CompilerParameters();

            // Add an assembly reference.
            cp.ReferencedAssemblies.Add("System.dll");
            cp.ReferencedAssemblies.Add("System.Xml.Linq.dll");
            cp.ReferencedAssemblies.Add("MyCommonDeclarations.dll");


            // Generate an executable instead of
            // a class library.
            cp.GenerateExecutable = false;

            // Set the assembly file name to generate.
//            cp.OutputAssembly = exeFile;

            // Save the assembly as a physical file.
            cp.GenerateInMemory = true;

            // Invoke compilation.
            CompilerResults cr = provider.CompileAssemblyFromSource(cp, strFullCode);

            if (cr.Errors.Count > 0)
            {
                // Display compilation errors.
/*                Console.WriteLine("Errors building {0} into {1}",
                    strFullCode, cr.PathToAssembly);
                foreach (CompilerError ce in cr.Errors)
                {
                    Console.WriteLine("  {0}", ce.ToString());
                    Console.WriteLine();
                }*/
            }
            else
            {
/*                Console.WriteLine("Source {0} built into {1} successfully.",
                    sourceFile, cr.PathToAssembly);*/
            }

            // Return the results of compilation.
            if (cr.Errors.Count > 0)
            {
                return null;
            }
            else
            {
                return cr.CompiledAssembly;
            }
        }

        int Counter = 1;
        private string GenAllCode(string strContentOfGetName, string strContentOfExecute)
        {
            string strTemplate =
                "using System; using System.Diagnostics; using System.Collections.Generic; using System.Text; namespace MyFlexibleCode { public class #####1 : MyCommonDeclarations.ICommand { public bool Execute(object[] input, ref object[] output) { #####2 } public string GetName() { #####3 } } } ";
            string strCode = strTemplate.Replace("#####1", 
                "MyClassName" + Counter.ToString());
            Counter++;

            strCode = strCode.Replace("#####2", strContentOfExecute);
            strCode = strCode.Replace("#####3", strContentOfGetName);

            return strCode;



 
        }
    }
}
