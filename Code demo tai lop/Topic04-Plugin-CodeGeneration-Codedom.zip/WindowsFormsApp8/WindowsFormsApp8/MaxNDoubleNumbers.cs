﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApp8
{
    public class MaxNDoubleNumbers : MyCommonDeclarations.ICommand
    {
        public bool Execute(object[] input, ref object[] output)
        {
            try
            {
                int N = int.Parse((string)input[0]);
                double[] v = new double[N];
                for (int i = 0; i < N; i++)
                    v[i] = double.Parse((string)input[i+1]);
                double res = FindMax(v);
                output = new object[1];
                output[0] = res;
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        private double FindMax(double[] v)
        {
            int n = v.Length;
            if (n == 0) return 0;
            double res = v[0];
            for (int i = 1; i < n; i++)
                if (res < v[i])
                    res = v[i];
            return res;
        }

        public string GetName()
        {
            return "Max of n floating-point numbers";
        }
    }
}